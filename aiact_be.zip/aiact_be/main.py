from src.app import app
import uvicorn

def main():
    config = uvicorn.Config(app=app, host="0.0.0.0", port=8000, reload=True, log_config=None)
    server = uvicorn.Server(config=config)
    server.run()


if __name__ == '__main__':
    main()
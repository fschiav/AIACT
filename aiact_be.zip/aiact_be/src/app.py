import pandas as pd
import io
import base64
import math
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from io import BytesIO
import sys
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi import FastAPI, Response, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi import BackgroundTasks, Form
from threading import Thread
from pydantic import BaseModel
import json

from src.sdv_generator import generator
from src.utils import df_compute_cat, sample_continuous

import logging
logger = logging.getLogger(__name__)
logging.basicConfig(stream=sys.stdout, level=logging.INFO)

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)

df = None
df_updated = None

categorical_vars = []
continuous_vars = []

MAN_NUM_ATTEMPS_GENERATOR = 20


class UpdateDistributionRequest(BaseModel):
    updated_feature: dict
    N: int


@app.get('/')
async def root():
    return {'message': 'Hello!'}


@app.post('/upload')
async def upload_csv(ignoredFeatures: str = Form(...), file: UploadFile = File(...)):
    global df, df_updated, categorical_vars, continuous_vars

    if not file.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail='Invalid file format.')

    try:
        ignoredFeaturesArr = json.loads(ignoredFeatures)
        contents = await file.read()
        df = pd.read_csv(io.StringIO(contents.decode('utf-8')))
        df.drop(columns=ignoredFeaturesArr, inplace=True)

        df_updated = df.copy()
        categorical_vars, continuous_vars = df_compute_cat(df)


        generator.setup_data(df_updated.copy(), categorical_vars)
        
        headers = df.columns.tolist()
        data_preview = df.head(10).values.tolist()
        return {'message': 'File uploaded successfully', 'headers': headers, 'data': data_preview}
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f'Error processing file: {str(e)}')


@app.get('/distribution/{feature}')
async def get_feature_distribution(feature: str):
    global df, df_updated

    if df is None:
        raise HTTPException(status_code=400, detail='No file has been uploaded.')
    
    if df.equals(df_updated):
        response = generate_distribution_response(df, feature)
    else: 
        response = generate_distribution_response(df, feature, df_updated)
    return JSONResponse(content=response)


@app.post('/update-distribution')
async def update_distribution(request: UpdateDistributionRequest):
    global df_updated
    
    updated_feature = request.updated_feature
    N = request.N
    feature = updated_feature['featureName']
    mean = updated_feature['mean']
    std = updated_feature['std']
    categories = updated_feature['categories']
    logging.info(f'Received distribution update request: {N=}, {feature=}, {mean=}, {std=}, {categories=}')

    if df_updated is None or feature not in df_updated.columns:
        raise HTTPException(status_code=400, detail='Error updating the feature')

    num_attempts_generator = 0


    try:
        if feature in continuous_vars:
            new_df_updated = sample_continuous(
                orig_dataframe=df_updated,
                target_mean=mean, target_sd=std,
                target_samples=N, col_name=feature,
                envelope=20
            )

            df_synths = []
            while len(new_df_updated) < N:
                if num_attempts_generator >= MAN_NUM_ATTEMPS_GENERATOR:
                    raise HTTPException(status_code=500, detail="Exceeded maximun number of generation attemps")
                num_attempts_generator += 1

                n_samples_to_generate = N - len(new_df_updated)
                logging.info(f'Generating {n_samples_to_generate} additional samples for feature {feature}')

                df_synth = generator.generate_samples(int(N * 5/3))
                df_synths.append(df_synth)
                
                df_sampled = sample_continuous(
                    orig_dataframe=pd.concat([new_df_updated] + df_synths),
                    target_mean=mean, target_sd=std,
                    target_samples=N, col_name=feature,
                    envelope=20
                )

                new_df_updated = df_sampled

            df_updated = new_df_updated
            print(f"{len(df_updated.index)}")

        elif feature in categorical_vars:
            total_required = sum(int(float(value)) for value in categories.values())
            if total_required != N:
                logger.info(f"The specified categories don't add up to {N}...")
                raise HTTPException(status_code=500, detail=f"specified categories don't add up to {N}...")

            selected_df = pd.DataFrame()
            missing_samples = {}

            for category, required_count in categories.items():
                required_count = int(float(required_count))
                available = df_updated[df_updated[feature] == category]

                if len(available) >= required_count:
                    cat_df = available.sample(required_count)
                else:
                    cat_df = available
                    missing_samples[category] = required_count - len(available)

                selected_df = pd.concat([selected_df, cat_df])

            while sum(int(float(value)) for value in missing_samples.values()):
                if num_attempts_generator >= MAN_NUM_ATTEMPS_GENERATOR:
                    raise HTTPException(status_code=500, detail="Exceeded maximun number of generation attemps")

                num_attempts_generator += 1
                logging.info(f"Generating more samples to meet category requirements: {missing_samples}")
                df_synth = generator.generate_samples(int(N * 5/3)) # TODO: fix this ratio

                for category, cat_count in missing_samples.items():
                    df_filtered_cat = df_synth[df_synth[feature] == category]
                    df_cat = df_filtered_cat.sample(min(cat_count, len(df_filtered_cat)))
                    selected_df = pd.concat(
                        [selected_df, df_cat], ignore_index=True)
                    missing_samples[category] = missing_samples[category] - len(df_cat)


            df_updated = selected_df

        response = generate_distribution_response(df, feature, df_updated)
        generator.setup_data(df_updated.copy(), categorical_vars)
        return JSONResponse(content=response)
    except HTTPException as e:
        raise e
    except Exception as e:
        logging.info(f'Encountered exception when sampling distribution: {e}')
        raise HTTPException(status_code=500, detail=f'Error updating distributions: {str(e)}')


def generate_distribution_response(base_df, feature, comparison_df=None):
    categorical_vars, continuous_vars = df_compute_cat(base_df)
    base_feature_data = base_df[feature]
    img_io = BytesIO()
    feature_type = None
    mean = None
    std = None
    categories = None

    plt.figure(figsize=(8, 6))

    if feature in categorical_vars:
        feature_type = 'categorical'
        if comparison_df is not None:
            comparison_feature_data = comparison_df[feature]
            value_counts = comparison_feature_data.value_counts(normalize=False)
            color='orange'
            categories = value_counts.to_dict()
            sns.histplot(comparison_feature_data, kde=False, discrete=True, color=color)
        else:
            value_counts = base_feature_data.value_counts(normalize=False)
            color='blue'
            categories = value_counts.to_dict()
            sns.histplot(base_feature_data, kde=False, discrete=True, color=color)
        
        plt.title(f'Histogram of {feature}')
        plt.xlabel(feature)
        plt.ylabel('Frequency')

    elif feature in continuous_vars:
        feature_type = 'continuous'
        sns.kdeplot(base_feature_data, fill=True, color='blue', alpha=0.5, label="Original")

        if comparison_df is not None:
            comparison_feature_data = comparison_df[feature]
            mean = float(comparison_feature_data.mean())
            std = float(comparison_feature_data.std())
            sns.kdeplot(comparison_feature_data, fill=True, color='orange', alpha=0.5, label="Updated")
        else:
            mean = float(base_feature_data.mean())
            std = float(base_feature_data.std())
            
        plt.title(f'Density Plot of {feature}')
        plt.xlabel(feature)
        plt.ylabel('Density')
        plt.legend()
    
    else:
        raise HTTPException(status_code=400, detail=f'Unknown data type for feature {feature}.')

    plt.savefig(img_io, format='png')
    img_io.seek(0)
    plt.close()

    image_base64 = base64.b64encode(img_io.getvalue()).decode('utf-8')
    image_base64 = f"data:image/png;base64,{image_base64}"

    return {
        "image": image_base64,
        "type": feature_type,
        "mean": mean,
        "std": std,
        "categories": categories
    }


@app.get(path='/download')
def generate():
    csv_buffer = io.StringIO()
    df_updated.to_csv(csv_buffer, index=False)
    csv_buffer.seek(0)

    return Response(
        content=csv_buffer.getvalue(),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=sample.csv"}
    )


@app.get('/numsamples')
def get_num_samples():
    return {'numsamples': len(df_updated)}
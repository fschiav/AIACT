import os
os.environ['CUDA_VISIBLE_DEVICES'] = ''

import pandas as pd
import numpy as np
import pickle

from tensorflow.keras.layers import Input, Dense
from tensorflow.keras.models import Model
from tensorflow.keras.callbacks import Callback
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.decomposition import PCA

NUM_EPOCHS = 2000
global_epoch = 0
label_encoders = {}
ss = StandardScaler()
pca = None
pca_latent_reduced = None
decoder_model = None


class print_training_on_text_every_10_epochs_Callback(Callback):
    def on_epoch_end(self, epoch, logs=None):
        global global_epoch
        global_epoch = epoch
        with open('log_epoch.log', "a") as writefile:
            if (int(epoch) % 100) == 0:
                s = f"Epoch: {epoch:>3}" + f" | Loss: {logs['loss']:.4e}\n"
                writefile.write(s)


def generate_data_(num_samples, columns, categorical_vars):
    global pca_latent_reduced, pca, decoder_model, ss, label_encoders

    pca_samples = pca_latent_reduced[np.random.choice(pca_latent_reduced.shape[0], num_samples, replace=True)]
    latent_samples_from_pca = pca.inverse_transform(pca_samples)
    generated_data = decoder_model.predict(latent_samples_from_pca)
    generated_data = ss.inverse_transform(generated_data)

    df_gen = pd.DataFrame(generated_data, columns=columns)
    for feature, feature_le in label_encoders.items():
        n = len(feature_le.classes_)
        steps = np.arange(0.5, n + 0.5, 1.0)

        df_gen[feature] = df_gen[feature].apply(lambda x: feature_le.inverse_transform(
            [np.argmin(np.fabs(x - steps))]
        ))
    
    return df_gen


def generate_data(num_samples, columns, categorical_vars):
    from tensorflow.keras.models import load_model
    with open('./auto_encoder/checkpoint/ss.pkl', 'rb') as f:
        ss = pickle.load(f)
    with open('./auto_encoder/checkpoint/pca.pkl', 'rb') as f:
        pca = pickle.load(f)
    pca_latent_reduced = np.load('./auto_encoder/checkpoint/pca_latent_reduced.npy')
    decoder_model = load_model('./auto_encoder/checkpoint/decoder_model.keras', compile=False)

    pca_samples = pca_latent_reduced[np.random.choice(pca_latent_reduced.shape[0], num_samples, replace=True)]
    latent_samples_from_pca = pca.inverse_transform(pca_samples)
    generated_data = decoder_model.predict(latent_samples_from_pca)
    generated_data = ss.inverse_transform(generated_data)

    df_gen = pd.DataFrame(generated_data, columns=columns)
    for var in categorical_vars:
        with open(f'./auto_encoder/checkpoint/{var}.pkl', 'rb') as f:
            le = pickle.load(f)

        n = len(le.classes_)
        steps = np.arange(0.5, n + 0.5, 1.0)

        df_gen[var] = df_gen[var].apply(lambda x: le.inverse_transform(
            [np.argmin(np.fabs(x - steps))]
        ))

    return df_gen


def setup_data(df, continuous_features, categorical_features):
    global ss, label_encoders

    for feature in categorical_features:
        le = LabelEncoder()
        label_encoders.update({feature: le})
        df[feature] = le.fit_transform(df[feature].astype(str))

    df = pd.DataFrame(ss.fit_transform(df), columns=df.columns, index=df.index)
    return ss, label_encoders


def setup_models(df):
    global decoder_model

    # Define parameters
    n_features = len(df.columns)
    latent_dim = 7

    # Encoder
    input_data = Input(shape=(n_features,), name="Input_Layer")
    encoder = Dense(64, activation="relu", name="Encoder_Hidden_1")(input_data)
    encoder = Dense(32, activation="relu", name="Encoder_Hidden_2")(encoder)
    latent_space = Dense(latent_dim, activation="linear", name="Latent_Space")(encoder)

    # Decoder
    decoder = Dense(32, activation="relu", name="Decoder_Hidden_1")(latent_space)
    decoder = Dense(64, activation="relu", name="Decoder_Hidden_2")(decoder)
    output_data = Dense(n_features, activation="linear", name="Output_Layer")(decoder)

    # Autoencoder Model
    autoencoder_model = Model(inputs=input_data, outputs=output_data, name="Autoencoder")
    autoencoder_model.compile(optimizer="adam", loss="mse")

    # Encoder Model
    encoder_model = Model(inputs=input_data, outputs=latent_space, name="Encoder")

    # Decoder Model
    decoder_input = Input(shape=(latent_dim,), name="Decoder_Input")
    decoder_layer1 = autoencoder_model.get_layer("Decoder_Hidden_1")(decoder_input)
    decoder_layer2 = autoencoder_model.get_layer("Decoder_Hidden_2")(decoder_layer1)
    decoder_output = autoencoder_model.get_layer("Output_Layer")(decoder_layer2)
    decoder_model = Model(inputs=decoder_input, outputs=decoder_output, name="Decoder")

    return encoder_model, decoder_model, autoencoder_model


def train(df, autoencoder, encoder):
    global pca, pca_latent_reduced

    history = autoencoder.fit(
        df.values, 
        df.values, 
        epochs=NUM_EPOCHS, batch_size=1024,
        validation_split=0.0, verbose=0, 
        callbacks=[print_training_on_text_every_10_epochs_Callback()]
    )
    
    latent_representations = encoder.predict(df.values)

    # Fit PCA on the latent representations
    pca = PCA()
    pca_latent = pca.fit_transform(latent_representations)

    n_components = np.argmax(np.cumsum(pca.explained_variance_ratio_) >= 0.95) + 1
    pca = PCA(n_components=n_components)
    pca_latent_reduced = pca.fit_transform(latent_representations)

    return pca, pca_latent_reduced


def save_model(decoder_model, pca, pca_latent_reduced, ss, le_dict):
    with open('./auto_encoder/checkpoint/pca.pkl', 'wb') as f:
        pickle.dump(pca, f)

    with open(file='./auto_encoder/checkpoint/ss.pkl', mode='wb') as f:
        pickle.dump(ss, f)

    for feature, le in le_dict.items():
        with open(file=f'./auto_encoder/checkpoint/{feature}.pkl', mode='wb') as f:
            pickle.dump(le, f)

    np.save(file='./auto_encoder/checkpoint/pca_latent_reduced.npy', arr=pca_latent_reduced, allow_pickle=True)
    decoder_model.save('./auto_encoder/checkpoint/decoder_model.keras')




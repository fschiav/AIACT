import numpy as np
import pandas as pd
from scipy.stats import gamma, norm
import utils
# from auto_encoder import auto_encoder
import matplotlib.pyplot as plt
import seaborn as sns

from sdv_generator import generator


def test_auto_encoder():
    df = pd.read_csv('../data/Cancer_Data_new_cols.csv')
    df.drop(columns=['id'], inplace=True)
    # df = utils.df_convert_dtypes(df)
    categorical_vars, continuous_vars = utils.df_compute_cat(df)

    ss, le_dict = auto_encoder.setup_data(df, [], ['diagnosis', 'ethnicity'])
    encoder_model, decoder_model, autoencoder_model = auto_encoder.setup_models(
        df)
    pca, pca_latent_reduced = auto_encoder.train(
        df, autoencoder_model, encoder_model)
    auto_encoder.save_model(
        decoder_model, pca, pca_latent_reduced, ss, le_dict)

    df_gen = auto_encoder.generate_data(100, df.columns, categorical_vars)
    df_gen.to_csv("df_gen_foo.csv")


def print_proportions(d):
    print(d['Gender'].value_counts(normalize=True))
    print(d['AgeGroup'].value_counts(normalize=True))
    print(pd.crosstab(d['Gender'], d['AgeGroup']))
    print(pd.crosstab(d['Gender'], d['AgeGroup'], normalize='all'))
    return None


def categorical_sampling(synthdata):
    print_proportions(synthdata)

    selected_indices = []
    selected_indices += list(synthdata[(synthdata['AgeGroup'] == '(30,60]') & (
        synthdata['Gender'] == 'Male')].sample(10).index)
    selected_indices += list(synthdata[(synthdata['AgeGroup'] == '(30,60]') & (
        synthdata['Gender'] == 'Female')].sample(10).index)
    selected_indices += list(synthdata[(synthdata['AgeGroup'] == '(60,100]') & (
        synthdata['Gender'] == 'Male')].sample(30).index)
    selected_indices += list(synthdata[(synthdata['AgeGroup'] == '(60,100]') & (
        synthdata['Gender'] == 'Female')].sample(50).index)
    mydata = synthdata.loc[selected_indices]
    print_proportions(mydata)


def mean_and_sd(x):
    return pd.DataFrame({'mean': [np.mean(x)], 'sd': [np.std(x)]})


def continuous_sampling(target_samples, orig_dataframe, col_name, target_mean, target_sd, envelope=1):
    r = []
    N = len(orig_dataframe)
    dens = np.histogram(orig_dataframe[col_name], bins=100, density=True)
    dens_x = (dens[1][1:] + dens[1][:-1]) / 2
    dens_y = dens[0] / np.sum(dens[0])

    dg = norm.pdf(dens_x, loc=target_mean, scale=target_sd)
    dg /= np.sum(dg)
    ref = dg / (dens_y * envelope)
    u = np.random.rand(N)

    for i in range(N - 1, -1, -1):
        row = orig_dataframe.iloc[i]
        pos = np.searchsorted(dens_x, row[col_name])
        if pos < len(ref) and u[i] < ref[pos] and ref[pos] < 0.5:
            r.append(row)
            if len(r) >= target_samples:
                break

    return pd.DataFrame(r)


def test_fiore():
    N = 1000
    np.random.seed(42)
    df = pd.DataFrame({
        'ID': np.arange(1, N + 1),
        'Gender': np.random.choice(['Male', 'Female'], N, replace=True),
        'Age': np.round(gamma(a=25, scale=2).rvs(N)),
        'Income': np.random.normal(loc=50000, scale=10000, size=N)
    })
    bins = [0, 30, 60, 100]
    labels = ['(0,30]', '(30,60]', '(60,100]']
    df['AgeGroup'] = pd.cut(df['Age'], bins=bins, labels=labels)

    categorical_sampling(df)

    mydata2 = continuous_sampling(
        orig_dataframe=df,
        target_mean=45000,
        target_sd=10000,
        target_samples=50,
        col_name='Income',
        envelope=6
    )

    print(mean_and_sd(df['Income']))
    print(mean_and_sd(mydata2['Income']))
    print(len(mydata2))
    print(mydata2.duplicated().sum())

    sns.kdeplot(df['Income'], bw_adjust=0.5, label='Original Income')
    sns.kdeplot(mydata2['Income'], bw_adjust=0.5, label='Sampled Income')
    plt.legend()
    plt.savefig('distribution_fiore.png')


def test_giro(df_updated):
    N = 1000

    # feature = 'diagnosis'
    categories = {'M': 500, 'B': 500}

    feature = 'radius_mean'
    mean, std = 20, 20
    
    print(f'{N=}, {feature=}, {mean=}, {std=}, {categories=}')
    print(df_updated['radius_mean'].describe())

    categorical_vars, continuous_vars = utils.df_compute_cat(df_updated)
    generator.setup_data(df_updated.copy(), categorical_vars)

    if feature in continuous_vars:
        df_sampled = utils.sample_continuous(
            orig_dataframe=df_updated,
            target_mean=mean, target_sd=std,
            target_samples=N, col_name=feature,
            envelope=20
        )

        while len(df_sampled) < N:
            n_samples_to_generate = N - len(df_sampled)
            print(
                f'Generating {n_samples_to_generate} additional samples for feature {feature}')

            df_synth = generator.generate_samples(int(2 * N * 5/3))
            df_updated = pd.concat([df_updated, df_synth])
            df_sampled = utils.sample_continuous(
                orig_dataframe=df_updated,
                target_mean=mean, target_sd=std,
                target_samples=N, col_name=feature,
                envelope=20
            )

        df_updated = df_sampled

        print(df_updated['radius_mean'].describe())
        return df_updated

    elif feature in categorical_vars:
        total_required = sum(int(float(value))
                             for value in categories.values())
        if total_required != N:
            print(f"Error: Specified categories don't add up to {N}!")
            return None

        selected_df = pd.DataFrame()
        missing_samples = {}

        for category, required_count in categories.items():
            required_count = int(float(required_count))
            available = df_updated[df_updated[feature] == category]

            if len(available) >= required_count:
                cat_df = available.sample(required_count)
            else:
                cat_df = available
                missing_samples[category] = required_count - len(available)

            selected_df = pd.concat([selected_df, cat_df])

        print(missing_samples)
        while sum(int(float(value)) for value in missing_samples.values()):
            print(
                f"Generating more samples to meet category requirements: {missing_samples}")

            # df_synth = auto_encoder.generate_data(int(N * 5/3), df_updated.columns, categorical_vars)
            df_synth = generator.generate_samples(int(N * 5/3)) # TODO: fix this ratio

            print(df_synth[['diagnosis']].value_counts())

            for category, cat_count in missing_samples.items():
                df_filtered_cat = df_synth[df_synth[feature] == category]
                df_cat = df_filtered_cat.sample(
                    min(cat_count, len(df_filtered_cat)))
                selected_df = pd.concat(
                    [selected_df, df_cat], ignore_index=True)
                missing_samples[category] = missing_samples[category] - \
                    len(df_cat)

        return selected_df
    else:
        print('unknown')
        return None


if __name__ == '__main__':
    # test_auto_encoder()
    # test_fiore()

    df = pd.read_csv('../data/Cancer_Data_new_cols.csv')
    df.drop(columns=['id'], inplace=True)

    df_updated = test_giro(df)
    print(len(df_updated))
    df_updated.to_csv('sample.csv', index=False)
    exit()

    bins = [0, 30, 60, 100]
    labels = ['(0,30]', '(30,60]', '(60,100]']
    df['AgeGroup'] = pd.cut(df['age'], bins=bins, labels=labels)
    print(df.head(10))

    print(mean_and_sd(df['radius_mean']))
    sample = continuous_sampling(
        orig_dataframe=df,
        target_mean=10.4,
        target_sd=2.1,
        target_samples=10,
        col_name='radius_mean',
        envelope=20
    )

    print(len(sample))
    print(sample.duplicated().sum())

    sns.kdeplot(df['radius_mean'], bw_adjust=0.5, label='Original Income')
    sns.kdeplot(sample['radius_mean'], bw_adjust=0.5, label='Sampled Income')
    plt.legend()
    plt.savefig('distribution.png')

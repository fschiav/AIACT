import numpy as np
from sdv.tabular import GaussianCopula
from sklearn.preprocessing import LabelEncoder

metadata = None
label_encoders = {}
synthesizer = None

def setup_data(df, categorical_features):
    global metadata, label_encoders, synthesizer

    synthesizer = GaussianCopula()

    for feature in categorical_features:
        le = LabelEncoder()
        label_encoders.update({feature: le})
        df[feature] = le.fit_transform(df[feature].astype(str))

    synthesizer.fit(df)


def generate_samples(num_samples):
    global label_encoders, synthesizer

    df_gen = synthesizer.sample(num_rows=num_samples)
    for feature, feature_le in label_encoders.items():
        n = len(feature_le.classes_)
        steps = np.arange(0.5, n + 0.5, 1.0)

        df_gen[feature] = df_gen[feature].apply(lambda x: feature_le.inverse_transform([x])[0])
    
    return df_gen
import pandas as pd
import numpy as np
from scipy.stats import gamma, norm


CATEGORICAL_UNIQUE_TRESHOLD = 10

def df_convert_dtypes(df):
    df = df.convert_dtypes()

    for col in df.select_dtypes(include=['string']).columns:
        if pd.to_datetime(df[col], errors='coerce').notna().all():
            df[col] = pd.to_datetime(df[col])

    return df


def df_compute_cat(df):
    categorical_vars = []
    continuous_vars = []

    for col in df.columns:
        if pd.api.types.is_numeric_dtype(df[col]):
            if df[col].nunique() < CATEGORICAL_UNIQUE_TRESHOLD:
                categorical_vars.append(col)
            else:
                continuous_vars.append(col)

        elif pd.api.types.is_bool_dtype(df[col]) or pd.api.types.is_categorical_dtype(df[col]) or pd.api.types.is_string_dtype(df[col]):
           categorical_vars.append(col)

    return categorical_vars, continuous_vars


def sample_continuous(target_samples, orig_dataframe, col_name, target_mean, target_sd, envelope=1):
    r = []
    N = len(orig_dataframe)
    dens = np.histogram(orig_dataframe[col_name], bins=100, density=True)
    dens_x = (dens[1][1:] + dens[1][:-1]) / 2   # punti medi dei bin
    dens_y = dens[0] / np.sum(dens[0])   # vettore di probabilità che un valore cada nel bin relativo
    
    dg = norm.pdf(dens_x, loc=target_mean, scale=target_sd)
    dg /= np.sum(dg)
    ref = dg / (dens_y * envelope)
    u = np.random.rand(N)
    
    for i in range(N - 1, -1, -1):
        row = orig_dataframe.iloc[i]
        pos = np.searchsorted(dens_x, row[col_name])
        if pos < len(ref) and u[i] < ref[pos] and ref[pos] < 0.5:
            r.append(row)
            if len(r) >= target_samples:
                break
    
    return pd.DataFrame(r)
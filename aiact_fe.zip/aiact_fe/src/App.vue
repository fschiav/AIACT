<template>
  <main>
    <Homepage />
  </main>
</template>

<script setup>
import Homepage from './views/HomeView.vue'
</script>

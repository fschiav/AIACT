<template>
    <div class="container">
        <h2>Upload .csv</h2>
        <input type="file" accept=".csv" @change="handleFileUpload" class="file-input" />

        <div v-if="allFeatures.length > 0" >
            <h1>Dataset features:</h1>
            <p>Select features to ignore</p>
            <div class="featureIgnoredContainer">
                <div v-for="(header, index) in allFeatures" :key="index" class="feature-item">
                    <div class="feature-header">
                        {{ header }}
                    </div>
                    <div class="checkbox-container">
                        <label for="checkbox">Disable:</label>
                        <input type="checkbox" id="checkbox" @change="handleCheckboxChange($event, header)" />
                    </div>
                </div>
            </div>
        </div>


        <div v-if="csvData.length">
            <h3>Original dataset preview</h3>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th v-for="(header, index) in csvHeaders" :key="index">{{ header }}</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(row, rowIndex) in csvData" :key="rowIndex">
                            <td v-for="(cell, cellIndex) in row" :key="cellIndex">{{ cell }}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <button v-if="selectedFile" @click="uploadData" :disabled="isUploading" class="upload-button">
            {{ isUploading ? "Uploading..." : "Upload Data" }}
        </button>
    </div>
</template>


<script setup>
import { ref, defineEmits } from 'vue';

const allFeatures = ref([])
const ignoredFeatures = ref([])
const csvHeaders = ref([]);
const csvData = ref([]);
const isUploading = ref(false);
const selectedFile = ref(null);
const emit = defineEmits(['csv-headers', 'csv-data']);

const handleCheckboxChange = (event, header) => {
    if (event.target.checked) {
        ignoredFeatures.value.push(header);
    }
};

const readFirstLine = (file) => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        const CHUNK_SIZE = 1024;

        reader.onload = (event) => {
            const text = new TextDecoder().decode(event.target.result);
            const firstLine = text.split("\n")[0];
            resolve(firstLine);
        };

        reader.onerror = reject;

        const blob = file.slice(0, CHUNK_SIZE);
        reader.readAsArrayBuffer(blob);
    });
};

const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (file) {
        selectedFile.value = file;
    }

    let header = await readFirstLine(file)
    allFeatures.value = header.split(",")
};

const uploadData = async () => {
    if (!selectedFile.value) {
        alert("No file selected.");
        return;
    }

    isUploading.value = true;
    const formData = new FormData();
    formData.append("file", selectedFile.value);
    formData.append("ignoredFeatures", JSON.stringify(ignoredFeatures.value));

    try {
        const response = await fetch("http://localhost:8000/upload", {
            method: "POST",
            body: formData
        });

        if (!response.ok) throw new Error("Upload failed");
        const result = await response.json();
        csvHeaders.value = result.headers;
        csvData.value = result.data;
        allFeatures.value = [];

        emit('csv-headers', csvHeaders.value);
        emit('csv-data', csvData.value);
    } catch (error) {
        alert("Error uploading data: " + error.message);
    } finally {
        isUploading.value = false;
    }
};
</script>


<style scoped>
.featureIgnoredContainer {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); 
    gap: 16px; 
    margin-top: 20px;
}

.feature-item {
    display: grid;
    grid-template-columns: 1fr auto; 
    align-items: center; 
    gap: 8px; 
    padding: 10px;
    background: #f9f9f9;
    border: 1px solid #ddd;
    border-radius: 6px;
    word-wrap: break-word; 
    word-break: break-word; 
    overflow: hidden; 
}

.feature-header {
    font-weight: bold;
    color: #333;
    white-space: normal; 
    line-height: 1.4; 
    overflow-wrap: break-word; 
}

.checkbox-container {
    display: flex;
    align-items: center;
    gap: 6px;
}

.checkbox-container label {
    font-size: 14px;
    color: #555;
}

.checkbox-container input[type="checkbox"] {
    width: 20px;
    height: 20px;
}


.container {
    margin: 40px auto;
    padding: 20px;
    background: #fff;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
    font-family: Arial, sans-serif;
}

h2 {
    font-size: 22px;
    margin-bottom: 15px;
    color: #333;
}

h3 {
    font-size: 18px;
    margin-top: 20px;
    color: #555;
}

.file-input {
    width: 100%;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 4px;
    margin-bottom: 15px;
    cursor: pointer;
}

.table-container {
    overflow-x: auto;
    margin-top: 10px;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
}

th,
td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
}

th {
    background-color: #f4f4f4;
}

.upload-button {
    display: block;
    width: 100%;
    padding: 10px;
    background: #007bff;
    color: white;
    border: none;
    border-radius: 4px;
    font-size: 16px;
    cursor: pointer;
    margin-top: 20px;
}

.upload-button:hover {
    background: #0056b3;
}

.upload-button:disabled {
    background: gray;
    cursor: not-allowed;
}

</style>

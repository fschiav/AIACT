<template>
    <div>
        Current number of samples: {{ numSamples }} - 
        Number of samples to retrieve: <input
            id="numSamples"
            type="number"
            v-model="number"
            class="numeric-input"
            placeholder="N"
            :min="1"
            @input="setNumSamples($event)"
        />
    </div>
    <div>
        <label id="data_generator_msg" :hidden="!numSamplesOk" style="color: red">The number of samples to be generated must be an integer greater than 0</label>
    </div>
</template>

<script setup>
import { ref } from "vue";
import contextService from "../services/Context";

const props = defineProps({ numSamples: Number });
const numSamplesOk = ref(true)
const setNumSamples = (event) => {
    if (event.target.value && !isNaN(Number(event.target.value)) && Number(event.target.value) > 0) {
        numSamplesOk.value = false
        contextService.numSamples = Number(event.target.value);
    } else {
        numSamplesOk.value = true
        contextService.numSamples = null
    }
};
</script>

<style scoped>


.numeric-input {
  width: 150px;
  padding: 8px;
  font-size: 16px;
  border: 1px solid #ccc;
  border-radius: 5px;
  outline: none;
  transition: border-color 0.2s;
}

.numeric-input:focus {
  border-color: #007bff;
  box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
}
</style>

<template>
    <button id="downloadCSV_btn" class="app-button" :disabled="numSamplesOk" @click="downloadCSV">Download dataset</button>
</template>

<script setup>

const downloadCSV = async () => {
    try {
        const response = await fetch(`http://localhost:8000/download`, {
            method: "GET",
        });

        if (!response.ok) {
            throw new Error("Failed to download CSV");
        }

        const blob = await response.blob();
        const link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.download = "sample.csv";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    } catch (error) {
        console.error("Error downloading CSV:", error);
    }
    return { downloadCSV };
}
</script>
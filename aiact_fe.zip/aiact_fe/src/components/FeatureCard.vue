<template>
    <div class="feature-card">
        <div class="feature-header">
            <span class="feature-title">
                <strong>{{ featureName }}</strong>
            </span>           
        </div>

        <div class="feature-content">
            <div class="feature-stats">
                <template v-if="featureInfo.type === 'continuous'">
                    <p><strong>Mean:</strong> <input v-model="featureInfo.mean" type="text" /></p>
                    <p><strong>Std. Dev:</strong> <input v-model="featureInfo.std" type="text" /></p>
                </template>
                <template v-else>
                    <p><strong>Adjust Categories:</strong></p>
                    <div v-for="(number, category) in featureInfo.categories" :key="category">
                        <label>{{ category }}:
                            <input v-model="featureInfo.categories[category]" type="text" @input="emitChanges" />
                        </label>
                    </div>
                </template>
            </div>

            <img v-if="featureInfo.image" :src="featureInfo.image" alt="Feature Distribution" class="plot" />
        </div>

        <div class="button-container">
            <button v-if="valuesUpdated" 
                :disabled="contextService.isCardDisabled" 
                @click="sendUpdatedDistribution" 
                class="update-button">
                Update
            </button>
        </div>
    </div>
</template>

<script setup>
import { ref, onMounted, defineProps, computed } from "vue";
import contextService from "../services/Context";

const emit = defineEmits(["rendered", "updatedFeature"]);
const props = defineProps({ featureName: String });
const featureInfo = ref({ image: null, type: null, mean: null, std: null, categories: {} });
const originalMean = ref(null);
const originalStd = ref(null);
const originalCategories = ref({});
const isDataLoaded = ref(false);


const valuesUpdated = computed(() => {
    if (!isDataLoaded.value) return false; 

    if (featureInfo.value.type == 'categorical') {
        return JSON.stringify(featureInfo.value.categories) !== JSON.stringify(originalCategories.value);
    }
    else {
        return parseFloat(featureInfo.value.mean) !== parseFloat(originalMean.value) || 
        parseFloat(featureInfo.value.std) !== parseFloat(originalStd.value) 
    } 
});

const fetchFeatureInfo = async () => {
    try {
        const response = await fetch(`http://localhost:8000/distribution/${props.featureName}`);
        if (response.ok) {
            emit("rendered");
            const data = await response.json();
            featureInfo.value = {
                ...data,
                mean: data.mean?.toFixed(2) || "",
                std: data.std?.toFixed(2) || "",
            };
            originalMean.value = featureInfo.value.mean;
            originalStd.value = featureInfo.value.std;
            originalCategories.value = JSON.parse(JSON.stringify(data.categories || {}));
            isDataLoaded.value = true;
        } else {
            throw new Error("Failed to fetch feature data");
        }
    } catch (error) {
        console.error("Error fetching feature data:", error);
    }
};

const sendUpdatedDistribution = async () => {
    const updatedFeature = {
        featureName: props.featureName,
        mean: parseFloat(featureInfo.value.mean) || 0,
        std: parseFloat(featureInfo.value.std) || 0,
        categories: featureInfo.value.categories,
    };

    if(featureInfo.value.type == 'categorical') {
        const sum = Object.values(updatedFeature.categories)
            .reduce((acc, val) => acc + parseInt(val, 10), 0);

        if (sum != contextService.numSamples) {
            alert("The count must sum up to " + contextService.numSamples)
            return
        }
    }

    try {
        contextService.updateFeatureLoading = true
        let response = await fetch("http://localhost:8000/update-distribution", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                "updated_feature": updatedFeature,
                "N": contextService.numSamples
            }),
        });
        if (!response.ok) {
            const errorData = await response.json();
            alert(errorData.detail);
        }
        contextService.updateFeatureLoading = false;
        emit("updatedFeature");
    } catch (error) {
        console.log("Error updating distribution for feature", props.featureName, ":", error);
    }
};

onMounted(fetchFeatureInfo);
</script>

<style scoped>
.feature-card {
    display: flex;
    flex-direction: column;
    align-items: center;
    border: 1px solid #ddd;
    padding: 20px;
    border-radius: 8px;
    background-color: #fff;
    max-width: 400px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    margin: auto;
}

.feature-header {
    display: flex;
    justify-content: space-between;
    width: 100%;
    align-items: center;
}

.feature-title {
    flex-grow: 1;
    text-align: center;
    font-size: 18px;
}


.feature-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    width: 100%;
    margin-top: 10px;
}

.feature-stats {
    text-align: center;
    margin-bottom: 10px;
}

.plot {
    max-width: 100%;
    height: auto;
    margin-top: 10px;
    border-radius: 5px;
}

.button-container {
    height: 40px; 
    display: flex;
    align-items: center;
    justify-content: center;
}

.update-button {
    margin-top: 15px;
    padding: 8px 15px;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    transition: background-color 0.3s;
}

.update-button:hover {
    background-color: #0056b3;
}

.update-button:disabled {
  background-color: #ccc; 
  color: #666; 
  cursor: not-allowed; 
  opacity: 0.6;
}


</style>
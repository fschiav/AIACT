<template>
    <div v-if="contextService.updateFeatureLoading" class="loading-overlay">
        <div class="left loader">
        </div>
        <div class="right">
          <p class="loading-text">Updating feature, please wait...</p>
        </div>
    </div>
</template>

<script setup>
import contextService from '@/services/Context';
</script>

<style scoped>
.fade-enter-active,
.fade-leave-active {
    transition: opacity 0.3s ease;
}

.fade-enter,
.fade-leave-to {
    opacity: 0;
}

.loading-text {
  color: white;
  font-size: 18px;
  font-weight: bold;
  margin-top: 15px;
  text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.5);
  animation: fadeInOut 1.5s infinite alternate;
}

@keyframes fadeInOut {
  from {
    opacity: 0.6;
  }
  to {
    opacity: 1;
  }
}

.loading-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5); 
  backdrop-filter: blur(5px); 
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
}

.loader {
  width: 60px;
  height: 60px;
  border: 6px solid #ccc;
  border-top-color: #007bff;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
</style>

<template>
    <!-- Used for training autoencoder. Not needed anymore-->
    <div>
        <button @click="trainModel" class="submit-button" :disabled="trainingInProgress">
            Train model on data
        </button>
        <div v-if="trainingInProgress" class="loading-indicator" :hidden="true">
            <div class="progress-bar-container">
                <div class="progress-bar" :style="{ width: progress + '%', transition: 'width 0.5s ease-in-out' }"></div>
            </div>
            <div v-if="percentage !== null" class="percentage-info">
                {{ percentage }}%
            </div>
        </div>
    </div>
</template>

<script setup>
import { ref, onUnmounted, onMounted } from 'vue'

import contextService from "../services/Context";

const emit = defineEmits(['trainingStarted', 'trainingCompleted'])

const trainingInProgress = ref(false)
const progress = ref(0)
let statusCheckInterval = null
const percentage = ref(null)

const trainModel = async () => {
    trainingInProgress.value = true
    progress.value = 0
    emit('trainingStarted')

    try {
        const response = await fetch('http://localhost:8000/train', 
            {
                method: 'POST' ,
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                }),
            })
        if (response.ok) {
            statusCheckInterval = setInterval(checkTrainingStatus, 2000) 
        } else {
            console.error("Error starting training process")
            trainingInProgress.value = false
        }
    } catch (error) {
        console.error("Error during model training:", error)
        trainingInProgress.value = false
    }
}

const checkTrainingStatus = async () => {
    try {
        const statusResponse = await fetch('http://localhost:8000/training-status', { method: 'GET' })
        console.log();
        
        if (statusResponse.ok) {
            const statusData = await statusResponse.json()
            
            if (statusData.percentage < 100) {
                percentage.value = statusData.percentage
                progress.value = Math.min(percentage.value, 100) 
            } else {
                clearInterval(statusCheckInterval)
                trainingInProgress.value = false
                emit('trainingCompleted')
                alert('Model training completed!')
            }
        } else {
            console.error('Error fetching training status')
            trainingInProgress.value = false
        }
    } catch (error) {
        console.error("Error checking training status:", error)
        trainingInProgress.value = false
    }
}


onMounted(() => {
    trainModel()
})


onUnmounted(() => {
    if (statusCheckInterval) {
        clearInterval(statusCheckInterval)
    }
})
</script>


<style scoped>
.submit-button {
    margin: 10px;
    padding: 10px 15px;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
}

.submit-button:hover {
    background-color: #0056b3;
}

.loading-indicator {
    margin-top: 20px;
    font-size: 16px;
    color: #888;
}

.progress-bar-container {
    width: 100%;
    background-color: #f3f4f6;
    border-radius: 25px;
    height: 20px;
    margin-top: 10px;
    box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
}

.progress-bar {
    height: 100%;
    background-color: #4CAF50;
    border-radius: 25px;
    transition: width 0.5s ease-in-out;
}

.percentage-info {
    margin-top: 5px;
    font-size: 14px;
    color: #555;
}
</style>

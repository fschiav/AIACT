import { reactive, computed, ref } from "vue";

const contextService = reactive({
    numSamples: ref<number | null>(null),
    updateFeatureLoading: ref(false),

    isCardDisabled: computed(() => contextService.numSamples === null),
});

export default contextService;

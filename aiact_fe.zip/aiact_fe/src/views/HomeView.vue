<template>
    <Loader />

    <div :class="{ 'blurred': contextService.updateFeatureLoading }">
        <img src="@/assets/logo_aiact.jpg" />
        <h1>AIACT</h1>

        <CsvUploader @csv-headers="handleCsvHeaders" @csv-data="handleCsvData" />
        
        <div v-show="csvData.length > 0" class="container">
            <button @click="isCollapsed = !isCollapsed" class="app-button">
                {{ isCollapsed ? "Show" : "Hide" }} Distributions
            </button>

            <DownloadDataset />

            <div v-show="!isCollapsed" class="collapsible-content">
                <DataGenerator v-if="csvData.length > 0" :numSamples="numSamples"/>
                <ul class="feature-list" :key="updateDistributionsKey">
                    <li v-for="header in csvHeaders" :key="header" class="feature-item">
                        <FeatureCard ref="featureCards" :featureName="header" 
                            @rendered="onDistributionRendered"
                            @updatedFeature="onDistributionUpdate" />
                    </li>
                </ul>
            </div>
        </div>
    </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import Loader from '@/components/Loader.vue';
import CsvUploader from '@/components/CsvUploader.vue';
import FeatureCard from '@/components/FeatureCard.vue';
import DataGenerator from '@/components/DataGenerator.vue';
import DownloadDataset from '@/components/DownloadDataset.vue';
import contextService from '@/services/Context';

const csvData = ref([]);
const csvHeaders = ref([]);
const featureCards = ref([]);
const isCollapsed = ref(false);
const numRenderedDistributions = ref(0);
const updateDistributionsKey = ref(0);
const numSamples = ref(0)

const handleCsvHeaders = (headers) => {
    csvHeaders.value = headers;
    getNumberOfSamples();
}

const handleCsvData = (data) => {
    csvData.value = data;
}

const onDistributionRendered = () => {
    numRenderedDistributions.value++;
}

const onDistributionUpdate = async () => {
    updateDistributionsKey.value++;
    getNumberOfSamples();
}

const getNumberOfSamples = async () => {
    try {
        const response = await fetch(`http://localhost:8000/numsamples`);
        if (response.ok) {
            const data = await response.json();
            numSamples.value = data.numsamples;
        } else {
            throw new Error("Failed to fetch number of current samples");
        }
    } catch (error) {
        console.error("Failed to fetch number of current samples:", error);
    }
}

</script>


<style scoped>
h1 {
    text-align: center;
}

.feature-list {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
    padding: 0;
    margin-top: 20px;
}

.feature-item {
    list-style-type: none;
    padding: 10px;
    font-family: Arial, sans-serif;
}

@media (max-width: 600px) {
    .feature-list {
        grid-template-columns: 1fr;
    }
}

.container {
    text-align: center;
    margin: 20px auto;
}

.collapsible-content {
    margin-top: 10px;
    padding: 15px;
    background: #f0f0f0;
    border-radius: 4px;
}

.blurred {
  filter: blur(5px);
  pointer-events: none; 
}
</style>
